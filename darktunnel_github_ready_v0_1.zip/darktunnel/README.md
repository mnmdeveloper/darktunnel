# DarkTunnel iOS

Первый SwiftUI-прототип интерфейса DarkTunnel.

## Загрузка в GitHub с iPhone

1. Распаковать ZIP в приложении «Файлы».
2. В репозитории открыть **Add file → Upload files**.
3. Загрузить содержимое папки, сохраняя структуру.
4. Commit message: `Initial DarkTunnel UI prototype`.
5. Открыть вкладку **Actions**.
6. Запустить **Build UI Prototype**.

## Подписанная IPA

Workflow `Build Signed IPA` автоматически получает Team ID и Bundle ID из provisioning profile, поэтому вводить Team ID вручную не нужно.

Перед запуском добавить Repository secrets:

- `P12_BASE64`
- `P12_PASSWORD`
- `MOBILEPROVISION_BASE64`
- `KEYCHAIN_PASSWORD`

Не загружать `.p12` и `.mobileprovision` как обычные файлы репозитория.

## Текущее состояние

Это UI-прототип с mock-подключением. Настоящий VPN пока не подключён.
