import SwiftUI

struct AnnouncementBanner: View {
    let announcement: AppAnnouncement
    let onDismiss: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(icon)
                .font(.title3)

            VStack(alignment: .leading, spacing: 3) {
                Text(announcement.title)
                    .font(.subheadline.bold())

                Text(announcement.message)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if announcement.dismissible {
                Button(action: onDismiss) {
                    Image(systemName: "xmark")
                        .font(.caption.bold())
                        .padding(7)
                        .background(.white.opacity(0.08), in: Circle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(13)
        .background(bannerColor.opacity(0.16), in: RoundedRectangle(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .stroke(bannerColor.opacity(0.3), lineWidth: 1)
        }
    }

    private var icon: String {
        switch announcement.severity {
        case .information: "ℹ️"
        case .warning: "⚠️"
        case .critical: "⛔️"
        }
    }

    private var bannerColor: Color {
        switch announcement.severity {
        case .information: .blue
        case .warning: .orange
        case .critical: .red
        }
    }
}
