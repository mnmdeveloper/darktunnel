import MapKit
import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var vpn: VPNViewModel

    @State private var mapPosition: MapCameraPosition = .automatic
    @State private var showSettings = false
    @State private var connectedThemeImageName: String?

    var body: some View {
        ZStack {
            background
                .ignoresSafeArea()

            LinearGradient(
                colors: [
                    .black.opacity(0.58),
                    .clear,
                    .black.opacity(0.28),
                    .black.opacity(0.72)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            VStack(spacing: 18) {
                topCard

                Spacer()

                connectionCard
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
            .padding(.bottom, 18)
        }
        .onAppear {
            mapPosition = vpn.mapPosition
            refreshThemeImage()
        }
        .onChange(of: vpn.state) {
            withAnimation(.easeInOut(duration: 1.5)) {
                mapPosition = vpn.mapPosition
            }

            if vpn.state.isConnected {
                refreshThemeImage()
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(vpn)
        }
    }

    @ViewBuilder
    private var background: some View {
        if vpn.selectedTheme.id == AppTheme.map.id {
            Map(position: $mapPosition, interactionModes: [])
                .mapStyle(.standard(elevation: .flat, emphasis: .muted))
                .allowsHitTesting(false)
        } else if vpn.state.isConnected,
                  let connectedThemeImageName,
                  UIImage(named: connectedThemeImageName) != nil {
            Image(connectedThemeImageName)
                .resizable()
                .scaledToFill()
                .transition(.opacity)
        } else {
            Color(red: 0.025, green: 0.04, blue: 0.065)
        }
    }

    private var topCard: some View {
        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("DarkTunnel")
                    .font(.system(size: 30, weight: .bold, design: .rounded))

                Text("30 дней подписки")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 5) {
                Label("3 / 30 дней", systemImage: "calendar")
                Label("5.9 / 30 ГБ", systemImage: "arrow.up.arrow.down")
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.title3)
                    .frame(width: 44, height: 44)
                    .background(.white.opacity(0.08), in: Circle())
            }
            .buttonStyle(.plain)
        }
        .padding(18)
        .glassCard(cornerRadius: 30)
    }

    private var connectionCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusHeader

            if let announcement = vpn.announcement,
               !vpn.state.isConnected {
                AnnouncementBanner(announcement: announcement) {
                    vpn.announcement = nil
                }
            }

            Divider().overlay(.white.opacity(0.12))

            Button {
                vpn.toggleConnection()
            } label: {
                HStack {
                    Image(systemName: buttonIcon)
                    Text(buttonTitle)
                        .fontWeight(.semibold)
                }
                .font(.title3)
                .frame(maxWidth: .infinity)
                .frame(height: 62)
                .background(buttonBackground, in: RoundedRectangle(cornerRadius: 22))
            }
            .buttonStyle(.plain)
        }
        .padding(18)
        .glassCard(cornerRadius: 30)
    }

    @ViewBuilder
    private var statusHeader: some View {
        switch vpn.state {
        case .disconnected:
            VStack(alignment: .leading, spacing: 5) {
                Label("VPN выключен", systemImage: "shield.slash")
                    .font(.title3.bold())
                Text("Автовыбор сервера")
                    .foregroundStyle(.secondary)
            }

        case .checkingNetwork:
            statusProgress(title: "Проверяем сеть…")

        case .connecting:
            statusProgress(title: "Подключаемся…")

        case .reconnecting:
            statusProgress(title: "Восстанавливаем соединение…")

        case .connected:
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Label("Подключено", systemImage: "checkmark.shield.fill")
                        .font(.title3.bold())

                    Text("\(flag(for: vpn.selectedServer.countryCode)) \(vpn.selectedServer.countryName) · \(vpn.selectedServer.city)")
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Text("\(vpn.selectedServer.latencyMilliseconds) мс")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(.green.opacity(0.16), in: Capsule())
            }

        case .error(let message):
            VStack(alignment: .leading, spacing: 5) {
                Label("Ошибка подключения", systemImage: "exclamationmark.triangle.fill")
                    .font(.title3.bold())
                Text(message)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func statusProgress(title: String) -> some View {
        HStack(spacing: 12) {
            ProgressView()
            Text(title)
                .font(.title3.bold())
        }
    }

    private var buttonTitle: String {
        switch vpn.state {
        case .connected, .connecting, .checkingNetwork, .reconnecting:
            "Отключиться"
        default:
            "Подключиться"
        }
    }

    private var buttonIcon: String {
        switch vpn.state {
        case .connected, .connecting, .checkingNetwork, .reconnecting:
            "xmark.circle.fill"
        default:
            "shield.fill"
        }
    }

    private var buttonBackground: some ShapeStyle {
        vpn.state.isConnected
            ? AnyShapeStyle(Color.white.opacity(0.08))
            : AnyShapeStyle(
                LinearGradient(
                    colors: [.white.opacity(0.18), .white.opacity(0.09)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private func refreshThemeImage() {
        connectedThemeImageName = vpn.randomConnectedImageName()
    }

    private func flag(for countryCode: String) -> String {
        countryCode
            .uppercased()
            .unicodeScalars
            .compactMap { UnicodeScalar(127397 + $0.value) }
            .map(String.init)
            .joined()
    }
}
