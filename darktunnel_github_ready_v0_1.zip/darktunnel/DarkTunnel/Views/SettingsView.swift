import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var vpn: VPNViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Скорость") {
                    Picker("Режим", selection: $vpn.speedMode) {
                        ForEach(SpeedMode.allCases) { mode in
                            VStack(alignment: .leading) {
                                Text(mode.title)
                                Text(mode.subtitle)
                            }
                            .tag(mode)
                        }
                    }
                    .pickerStyle(.inline)
                }

                Section("Оформление") {
                    Picker("Тема", selection: $vpn.selectedThemeID) {
                        ForEach(vpn.themes) { theme in
                            Text(theme.name).tag(theme.id)
                        }
                    }
                }

                Section("Сон и пробуждение") {
                    Toggle("Отключать VPN при блокировке", isOn: $vpn.disconnectOnSleep)
                    Toggle("Подключать после пробуждения", isOn: $vpn.reconnectAfterWake)
                }

                Section {
                    Toggle("Направлять Apple Push через VPN", isOn: $vpn.routeAPNsThroughVPN)

                    Text("При нестабильном соединении системные уведомления могут приходить с задержкой.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } header: {
                    Text("Полный туннель")
                }

                Section("Диагностика") {
                    LabeledContent("Сервер", value: "\(vpn.selectedServer.countryName), \(vpn.selectedServer.city)")
                    LabeledContent("Транспорт", value: "Автоматически")
                    LabeledContent("Соединения", value: "\(vpn.speedMode.connections)")
                    LabeledContent("MTU", value: "Auto")
                }
            }
            .navigationTitle("Настройки")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }
}
