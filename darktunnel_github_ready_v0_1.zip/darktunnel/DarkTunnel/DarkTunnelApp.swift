import SwiftUI

@main
struct DarkTunnelApp: App {
    @StateObject private var vpn = VPNViewModel()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(vpn)
                .preferredColorScheme(.dark)
        }
    }
}
