import SwiftUI

private struct GlassCardModifier: ViewModifier {
    let cornerRadius: CGFloat

    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius))
            .background(
                Color.black.opacity(0.28),
                in: RoundedRectangle(cornerRadius: cornerRadius)
            )
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius)
                    .stroke(.white.opacity(0.10), lineWidth: 1)
            }
            .shadow(color: .black.opacity(0.22), radius: 24, y: 10)
    }
}

extension View {
    func glassCard(cornerRadius: CGFloat) -> some View {
        modifier(GlassCardModifier(cornerRadius: cornerRadius))
    }
}
