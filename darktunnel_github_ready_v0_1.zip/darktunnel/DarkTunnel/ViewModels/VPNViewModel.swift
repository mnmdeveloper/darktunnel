import Foundation
import MapKit
import SwiftUI

@MainActor
final class VPNViewModel: ObservableObject {
    @Published var state: VPNConnectionState = .disconnected
    @Published var selectedServer: VPNServer = .washington
    @Published var speedMode: SpeedMode = .balanced
    @Published var announcement: AppAnnouncement? = .maintenance
    @Published var receivedBytes: UInt64 = 0
    @Published var sentBytes: UInt64 = 0
    @Published var connectedAt: Date?

    @AppStorage("selectedThemeID") var selectedThemeID = AppTheme.map.id
    @AppStorage("disconnectOnSleep") var disconnectOnSleep = false
    @AppStorage("reconnectAfterWake") var reconnectAfterWake = true
    @AppStorage("routeAPNsThroughVPN") var routeAPNsThroughVPN = true

    let themes: [AppTheme] = [.map, .summer]

    var selectedTheme: AppTheme {
        themes.first(where: { $0.id == selectedThemeID }) ?? .map
    }

    var mapPosition: MapCameraPosition {
        let coordinate: CLLocationCoordinate2D

        if state.isConnected {
            coordinate = selectedServer.coordinate
        } else {
            coordinate = .init(latitude: 55.7558, longitude: 37.6173)
        }

        return .camera(
            MapCamera(
                centerCoordinate: coordinate,
                distance: state.isConnected ? 42_000 : 58_000,
                heading: 0,
                pitch: 0
            )
        )
    }

    func toggleConnection() {
        switch state {
        case .disconnected, .error:
            Task { await connect() }
        case .connected, .connecting, .checkingNetwork, .reconnecting:
            disconnect()
        }
    }

    func connect() async {
        state = .checkingNetwork
        try? await Task.sleep(for: .milliseconds(700))

        state = .connecting
        try? await Task.sleep(for: .seconds(1.2))

        state = .connected
        connectedAt = Date()
        receivedBytes = 5_900_000
        sentBytes = 1_100_000
    }

    func disconnect() {
        state = .disconnected
        connectedAt = nil
        receivedBytes = 0
        sentBytes = 0
    }

    func randomConnectedImageName() -> String? {
        selectedTheme.connectedImageNames.randomElement()
    }
}
