import CoreLocation
import Foundation

enum VPNConnectionState: Equatable {
    case disconnected
    case checkingNetwork
    case connecting
    case connected
    case reconnecting
    case error(String)

    var isConnected: Bool {
        if case .connected = self { return true }
        return false
    }
}

enum SpeedMode: String, CaseIterable, Identifiable {
    case balanced
    case maximum

    var id: String { rawValue }

    var title: String {
        switch self {
        case .balanced: "Сбалансированная"
        case .maximum: "Максимальная"
        }
    }

    var subtitle: String {
        switch self {
        case .balanced: "3 соединения — быстрое подключение"
        case .maximum: "10 соединений — максимальная скорость"
        }
    }

    var connections: Int {
        switch self {
        case .balanced: 3
        case .maximum: 10
        }
    }
}

struct VPNServer: Identifiable, Equatable {
    let id: UUID
    let countryCode: String
    let countryName: String
    let city: String
    let coordinate: CLLocationCoordinate2D
    let latencyMilliseconds: Int

    static let washington = VPNServer(
        id: UUID(),
        countryCode: "US",
        countryName: "США",
        city: "Вашингтон",
        coordinate: .init(latitude: 38.9072, longitude: -77.0369),
        latencyMilliseconds: 191
    )
}

struct AppAnnouncement: Identifiable, Equatable {
    enum Severity {
        case information
        case warning
        case critical
    }

    let id: UUID
    let severity: Severity
    let title: String
    let message: String
    let dismissible: Bool

    static let maintenance = AppAnnouncement(
        id: UUID(),
        severity: .warning,
        title: "Ведутся технические работы",
        message: "Некоторые серверы могут быть временно недоступны.",
        dismissible: true
    )
}

struct AppTheme: Identifiable, Codable, Equatable {
    enum OffMode: String, Codable {
        case dark
        case image
    }

    let id: String
    let name: String
    let description: String
    let offMode: OffMode
    let offImageNames: [String]
    let connectedImageNames: [String]

    static let map = AppTheme(
        id: "map",
        name: "Карта",
        description: "Живая карта Apple Maps",
        offMode: .dark,
        offImageNames: [],
        connectedImageNames: []
    )

    static let summer = AppTheme(
        id: "summer",
        name: "Летний фон",
        description: "Ощутите лето вместе с нашим VPN",
        offMode: .dark,
        offImageNames: [],
        connectedImageNames: ["summer_connected_1", "summer_connected_2"]
    )
}
